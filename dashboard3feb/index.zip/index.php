<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="./asset/css/style.css">
  <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>

  <title>HOME</title>
  <style>
    .footer1 {
      background-image: linear-gradient(to right, rgb(79, 4, 79), rgb(193, 91, 193));
      /* padding: 5%; */
      text-align: center;
      position: fixed;
      bottom: 0;
      padding: 0.3% 0% 0.3% 0%;
      color: #fff;
      width: 100%;
    }

    .linkbtn {
      background-color: transparent;
      border: unset;
      color: black;
    }

    .linkbtn:hover,
    .linkbtn:active,
    .linkbtn:after,
    .linkbtn:before {
      background-color: transparent;
      border: unset;
      color: black;
    }
  </style>
</head>
<?php
session_start();
$conn = mysqli_connect('localhost', 'root', '', 'graceerp');
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
?>

<body>
  <div class="sidebar close">
    <div class="logo-details">
      <img src="gcoe_logo.png" width="60px" height="50px">
      <span class="logo_name" style="font-size:18px;"> GRACE COE THOOTHUKUDI</span>
    </div>
    <ul class="nav-links">
      <li>
        <a href="./home.php" target="output_source">
          <i class='bx bxs-home'></i>
          <span class="link_name" style="font-size:15px;">Home</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="./home.php" target="output_source">Home</a></li>
        </ul>
      </li>
      <li>
        <a href="./dashboard.php" target="output_source">
          <i class='bx bxs-dashboard'></i>
          <span class="link_name" style="font-size:15px;">Dashboard</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="./dashboard.php" target="output_source">Dashboard</a></li>
        </ul>
      </li>
      <li>
        <a href="../AdminModule/Admin.php" target="output_source">
          <i class='bx bxs-user'></i>
          <span class="link_name" style="font-size:15px;">Admin module</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="../AdminModule/Admin.php" target="output_source">Admin module</a></li>
        </ul>
      </li>
      <li>
        <a href="../attendenceposting/facdrpatt.php" target="output_source">
          <i class='bx bx-bar-chart-alt-2'></i>
          <span class="link_name" style="font-size:15px;">Attendance posting</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="../attendenceposting/facdrpatt.php" target="output_source">Attendance posting</a></li>
        </ul>
      </li>
      <li>
        <a href="../attendenceposting/facdrpres.php" target="output_source">
          <i class='bx bx-bar-chart-square'></i>
          <span class="link_name" style="font-size:15px;">Result posting</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="../attendenceposting/facdrpres.php" target="output_source">Result posting</a></li>
        </ul>
      </li>
      <li>
        <div class="iocn-link">
          <a href="../reports/reports.php" target="output_source">
            <i class='bx bxs-report'></i>
            <span class="link_name" style="font-size:15px;">Reports</span>
          </a>
        </div>
        <ul class="sub-menu">
          <li><a class="link_name" href="../reports/reports.php" target="output_source">Reports</a></li>
        </ul>
      </li>
      <li>
        <a href="#">
          <i class='bx bx-photo-album'></i>
          <span class="link_name" style="font-size:15px;">Gallery</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="#">Gallery</a></li>
        </ul>
      </li>
      <li>
        <a href="">
          <i class='bx bxs-user'></i>
          <span class="link_name" style="font-size:15px;"> Profile</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="#">Profile</a></li>
        </ul>
      </li>
      <li>
        <a href="#">
          <i class='bx bxs-calendar'></i>
          <span class="link_name" style="font-size:15px;">View calender</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="#">View calender</a></li>
        </ul>
      </li>
      <li>
        <a href="#">
          <i class='bx bxs-lock-open-alt'></i>
          <span class="link_name" style="font-size:15px;">Change password</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="#">Change password</a></li>
        </ul>
      </li>
      <li>
        <a href="../logout.php">
          <i class='bx bx-log-out icon'></i>
          <span class="link_name" style="font-size:15px;">Logout</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="../logout.php">Logout</a></li>
        </ul>
      </li>
    </ul>
  </div>
  <section class="home-section">
    <div class="home-content">
      <i class='bx bx-menu'></i>
      <img id="responsive-image" src="./asset/img/grace.png">
      <img id="responsive-image" src="./asset/img/coe.png">
      <span id="ctl00_lblWelcometext" style="color:black;background-color:white;font-size:20px;font-weight:normal;font-style:italic;">Welcome <?php echo   $_SESSION['user_id']; ?> </span>
    </div>
  </section>

  <section class="content_frame" style="padding: 20px;">
    <iframe src="./home.php" name="output_source" frameborder="0" width="100%" height="1000px"></iframe>
  </section>

  <!-- <div class="footer1" id="footerNew">
    <p class="p-class"> All rights reserved by © GRACE COLLEGE OF ENGINEERING</p>
    <p class="p-class"> Developed and Maintained by CSE Students(BATCH 2020-2024).</p>
  </div> -->
</body>
<script>
  let arrow = document.querySelectorAll(".arrow");
  for (var i = 0; i < arrow.length; i++) {
    arrow[i].addE
    ventListener("click", (e) => {
      let arrowParent = e.target.parentElement.parentElement; //selecting main parent of arrow
      arrowParent.classList.toggle("showMenu");
    });
  }
  let sidebar = document.querySelector(".sidebar");
  let sidebarBtn = document.querySelector(".bx-menu");
  console.log(sidebarBtn);
  sidebarBtn.addEventListener("click", () => {
    sidebar.classList.toggle("close");
  });
</script>

</html>